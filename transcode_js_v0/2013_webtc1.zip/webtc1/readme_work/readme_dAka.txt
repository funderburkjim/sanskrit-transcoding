001       H3,dasyuhan,91160
002       H4,dasyuhantama,91161
003       H4A,dasyuhantama,91162
004       H1,dasra,91163
005       H1,dah,91164
006       H2,dah,91165
007       H3,dahati,91166
008       H2,dahadahA,91167
009       H2,dahana,91168
010       H2A,dahana,91169
011       H2B,dahana,91170
012       H2B,dahana,91171
013       H2B,dahana,91172
014       H2B,dahana,91173
015       H2B,dahana,91174
016       H2B,dahana,91175
017       H2B,dahana,91176
018       H2B,dahana,91177
019       H2B,dahana,91178
020       H2B,dahana,91179
021       H2B,dahana,91180
022       H2B,dahanA,91181
023       H2B,dahanI,91182
024       H3,dahanakarman,91183
025       H3,dahanaketana,91184
026       H3,dahanagarBa,91185
027       H3,dahanatA,91186
028       H3,dahanapriyA,91187
029       H3,dahanarkza,91188
030       H3,dahanavat,91188.1
031       H3,dahanasAraTi,91188.2
032       H3,dahanahalpa,91188.3
033       H3,dahanAguru,91189
034       H3,dahanArAti,91190
035       H3,dahanopakaraRa,91191
036       H3,dahanopala,91192
037       H3,dahanolkA,91193
038       H2,dahanIya,91194
039       H3,dahanIyatA,91195
040   1   H3,dahanIyatva,91196
041       H1,dahara,91197
042       H1A,dahara,91198
043       H1B,dahara,91199
044       H1B,dahara,91200
045       H1B,dahara,91201
046   2   H1B,dahara,91202
047   3   H3,daharapfzWa,91203
048   4   H3,daharasUtra,91204
049   5   H2,daharaka,91205
050   6   H2,dahra,91206
051   7   H2C,dahram,91207
052   8   H2B,dahra,91208
053   9   H3,dahrAgni,91209
054  10   H1,dahyu,91209.1
055  11   H1,dahra,91210
056       H1A,dahra,91211
057       H1,dA,91212
058       H2,dA,91213
059       H2B,dA,91214
060  12   H2B,dA,91215
061  13   H2,dAka,91216
062       H2A,dAka,91217
063  14   H2,dAta,91218
064  15   H3,dAtavya,91219
065       H3A,dAtavya,91220
066       H3A,dAtavya,91221
067       H3A,dAtavya,91222
068       H3A,dAtavya,91223
069       H3A,dAtavya,91224
070  16   H3,dAti,91225
071  17   H4,dAtivAra,91225.1
072  18   H2,dAtf,91226
073       H3,dAtf,91227
074       H3A,dAtf,91227.1
075       H3A,dAtf,91227.2
076       H3A,dAtf,91227.3
077       H3A,dAtf,91227.4
078       H3A,dAtf,91227.5
079       H3A,dAtf,91227.6
080       H3A,dAtf,91227.7
081  19   H3,dAtftA,91228
082  20   H3,dAtftva,91229
083  21   H3,dAtfnirUpaRa,91230
084  22   H3,dAtfpura,91231
085  23   H3,dAtfpratIcCaka,91231.1
086  24   H2,dAtta,91232
087  25   H3,dAttAmitrI,91233
088       H4,dAttAmitrIya,91234
089       H2,dAtteya,91235
090       H2,dAtva,91236
091       H2B,dAtva,91237
092       H2,dAda,91238
093       H3,dAdada,91239
094       H2,dAdin,91240
095       H2,dAna,91241
096       H2A,dAna,91242
097       H2A,dAna,91243
098       H2A,dAna,91244
099       H2A,dAna,91245
100       H2A,dAna,91246
101       H2A,dAna,91247
102       H2A,dAna,91248
103       H2A,dAna,91249
104       H2A,dAna,91250
105       H3,dAnakamalAkara,91251
106       H3,dAnakalpataru,91252
107       H3,dAnakAma,91253
108       H3,dAnakusumAYjali,91254
109       H3,dAnakelikOmudI,91255
110       H3,dAnakOmudI,91256
111       H3,dAnakOstuBa,91257
112       H3,dAnakriyAkOmudI,91258
113       H3,dAnaKaRqa,91259
114       H3,dAnacandrikA,91260
115       H3,dAnacyuta,91261
116       H3,dAnatas,91262
117       H3,dAnadarpaRa,91263
118       H3,dAnadinakara,91264
119       H3,dAnaDarma,91265
120       H4,dAnaDarmakaTana,91265.05
121       H4,dAnaDarmaviDi,91265.1
