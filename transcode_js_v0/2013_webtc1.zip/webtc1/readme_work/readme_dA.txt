001       H3,tvezanfmRa,89163
002       H3,tvezapratIka,89164
003       H3,tvezayAma,89165
004       H3,tvezaraTa,89166
005       H3,tvezasaMdfS,89167
006       H2,tvezaTa,89168
007       H2,tvezas,89169
008       H3,tvezin,89170
009       H2,tvezya,89171
010       H1,tvezita,89172
011       H1,tvE,89173
012       H1A,tvE,89173.1
013       H1,tvota,89174
014       H1,tsar,89175
015       H2,tsarA,89176
016       H2,tsaru,89177
017       H2A,tsaru,89178
018       H2A,tsaru,89179
019       H2A,tsaru,89180
020       H3,tsarumat,89181
021       H3,tsarumArga,89182
022       H3,tsaruka,89183
023       H2,tsAra,89184
024       H3,tsArin,89185
025       H3,tsAruka,89186
026       H1,Ta,89187
027       H3,TakAra,89188
028       H2,Ta,89189
029       H2A,Ta,89190
030       H2A,Ta,89191
031       H2A,Ta,89192
032       H2A,Ta,89193
033       H2B,Ta,89194
034       H2B,Ta,89195
035       H2B,Ta,89196
036       H1,Takkana,89197
037       H1,Takriya,89198
038       H1,Takviyaka,89199
039       H1,TaraTarAya,89200
040       H1,Tarv,89201
041       H1,Talyoraka,89202
042       H1,Tuq,89203
043       H1,TutkAra,89204
044       H2,TutTukAraka,89205
045       H2,TuTu,89206
046       H3,TuTukft,89207
047       H1,Turv,89208
048    1  H1,TUt,89209
049    2  H3,TUtkAra,89210
050    3  H3,TUtkfta,89211
051    4  H3,TUtkftya,89212
052    5  H3,TUTU,89213
053    6  H1,TETE,89214
054    7  H1,Toqana,89215
055    8  H1,TOReya,89216
056    9  H1,TOReyaka,89216.1
057   10  H1,da,89217
058   11  H3,dakAra,89218
059       H1,da,89219
060   12  H1B,da,89220
061   13  H1B,dA,89221
062   14  H1,da,89222
063       H1B,da,89223
064       H1B,dA,89224
065       H1,da,89225
066       H1,da,89226
067       H1A,da,89226.1
068       H1,da,89227
069       H1B,da,89228
070       H1B,dA,89229
071   15  H1,daMS,89230
072       H1,daMS,89231
073   16  H2,daMSa,89232
074       H2B,daMSa,89233
075       H2B,daMSa,89234
076       H2B,daMSa,89235
077       H2B,daMSa,89236
078       H2B,daMSa,89237
079       H2B,daMSa,89238
080       H2B,daMSa,89239
081       H2B,daMSa,89240
082       H2B,daMSa,89241
083   17  H2B,daMSI,89242
084   18  H2B,daMSa,89243
085   19  H3,daMSanASinI,89244
086   20  H3,daMSaBIru,89245
087   21  H3,daMSaBIruka,89246
088   22  H3,daMSamaSaka,89247
089       H3A,daMSamaSaka,89248
090   23  H3,daMSamUla,89249
091   24  H3,daMSavadana,89250
092   25  H2,daMSaka,89251
093       H2B,daMSaka,89252
094       H2B,daMSaka,89253
095       H2B,daMSaka,89254
096       H2B,daMSaka,89255
097       H2B,daMSikA,89256
098       H3,daMSana,89257
099       H3A,daMSana,89258
100       H3A,daMSana,89259
101       H3,daMSita,89260
102       H3A,daMSita,89261
103       H3A,daMSita,89262
104       H3A,daMSita,89263
105       H3A,daMSita,89264
106       H3A,daMSita,89265
107       H3B,daMSita,89266
108       H3,daMSin,89267
109       H3B,daMSin,89268
110       H3B,daMSin,89269
111       H2,daMSuka,89270
112       H2,daMSera,89271
113       H3,daMSman,89272
114       H3A,daMSman,89273
115       H2,daMzwf,89274
116       H2,daMzwra,89275
117       H2B,daMzwrA,89276
118       H2B,daMzwra,89277
119       H2,daMzwrA,89278
120       H3,daMzwrAkarAla,89279
121       H4,daMzwrAkarAlavat,89280
