VKI.devAnalysis_keyboard = function(evt)
// fromVirtualKeyboard = true;
{
 // devanagari or roman transliteration display of phonetic input
 var rc = true; // browser handles keystroke
 var tagName = null;
 var el = null;
 var ch = null;
 
 el = evt.currentTarget;
 if (!el.$keystroke) {
    el = el.parentNode;
 }
 ch = el.$keystroke;
 if (VKI_passThrough){
  VKI_insert(ch);
  return false;
 }

 var idx = VKI_getCaretPosition(VKI_target);
 //?? will this do a copy? Probably not since strings are immutable
 var text = VKI_target.value; 

 if (VKI_keymap.legalCharacter(ch)) {
  if (VKI_viewAs == "roman") {
   var km = VKI_keymap.lookupKeystroke(ch, false);
   VKI_insert(km.encodingRoman);
   rc = false;
  } else {
   var replace = [true];
   var current = UnicodeLogic.getSyllable(text, idx - 1);
   var prevchar = idx > 0 ? text.charAt(idx - 1) : '\0'; 
   var newSyllable = VKI_keymap.getUnicode(current, prevchar, ch, replace);
   if (newSyllable != null)  {
    // if character was intercepted by keymap
    if (replace[0]) {
     // e.g., current ends with virama
     if (current != null)  {
      VKI_replace(VKI_target, current.length, newSyllable);
     }else {
      VKI_replace(VKI_target, 1, newSyllable);
     }
    } else {
     VKI_insert(newSyllable); 
    }
    rc = false; // let browser know we have handled keystroke 
   } else  {
   // do nothing, leave character as is.
     rc = true;
   }
  }
 } else {
  VKI_insert(this.firstChild.nodeValue);
  VKI_currentCaretPosition++;
  // do nothing, leave character as is.
  rc = true; 
 }
 
 return rc;
}