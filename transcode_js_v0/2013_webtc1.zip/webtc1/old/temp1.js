VKI.devAnalysis_keypress = function(evt){
//  var fromVirtualKeyboard = false;
 var rc = true; // browser handles keystroke
 if (evt.ctrlKey || evt.altKey) {
   return rc; 
 }
 if (VKI.passThrough) {
  return rc;
 }
 var tagName = null;
 var el = null;
 var ch = String.fromCharCode(evt.which); 
 var idx = VKI.getCaretPosition(VKI.target);
 //?? will this do a copy? Probably not since strings are immutable
 var text = VKI.target.value; 
 if (VKI.keymap.legalCharacter(ch)) {
  if (VKI.viewAs == "roman") {
   var km = VKI.keymap.lookupKeystroke(ch, false);
   VKI.insert(km.encodingRoman);
   rc = false;
  }else {
   //viewas = "deva"
   var replace = [true];
   var current = UnicodeLogic.getSyllable(text, idx - 1);
   var prevchar = idx > 0 ? text.charAt(idx - 1) : '\0'; 
   var newSyllable = VKI.keymap.getUnicode(current, prevchar, ch, replace);
   if (newSyllable != null) { 
    // if character was intercepted by keymap
    if (replace[0]) {
     // e.g., current ends with virama
     if (current != null){
      VKI.replace(VKI.target, current.length, newSyllable);
     }else{
      VKI.replace(VKI.target, 1, newSyllable);
     }
    }else {
     VKI.insert(newSyllable); 
    }
    rc = false; // let browser know we have handled keystroke 
   }else {
    // do nothing, leave character as is.
    rc = true;
   }
  }
 } else {
  // not a legal character
  VKI.currentCaretPosition++;
  rc = true; 
 } 
 return rc;
}
